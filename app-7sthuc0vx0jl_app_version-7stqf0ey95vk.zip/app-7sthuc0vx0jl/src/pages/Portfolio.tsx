import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import AnimatedBackground from '@/components/AnimatedBackground';
import { GraduationCap, Trophy, Code, Briefcase, ExternalLink, Linkedin } from 'lucide-react';

export default function Portfolio() {
  const academics = [
    {
      level: 'Class 10',
      school: 'Mount Carmel ICSE School',
      location: 'Patna, Bihar',
      score: '92%',
    },
    {
      level: 'Class 12',
      school: "St. Paul's High School",
      board: 'CBSE',
      score: '93%',
    },
    {
      level: 'Current',
      school: 'SRM University Sonipat',
      status: 'Student',
    },
  ];

  const achievements = [
    {
      title: 'NDA Merit Out',
      description: 'Achieved merit in National Defence Academy examination',
      image: 'https://miaoda-site-img.s3cdn.medo.dev/images/177d5ac8-f043-45d7-a87b-4914783e24f5.jpg',
    },
    {
      title: 'National Level Tabla Player',
      description: 'Performed at renowned platforms including Sonpur Mela (Asia\'s largest Sonpur Fair)',
      image: 'https://miaoda-site-img.s3cdn.medo.dev/images/8b0ed846-e05c-4172-b4ce-8575260378dc.jpg',
    },
  ];

  const skills = {
    languages: ['Java (DSA)', 'C', 'JavaScript', 'HTML', 'CSS'],
    interests: 'Vibe coding and learning enthusiast',
  };

  return (
    <div className="relative min-h-screen">
      <AnimatedBackground />
      
      <div className="relative z-10 container mx-auto px-4 py-12 xl:py-20">
        <section className="mb-16 xl:mb-24 text-center animate-fade-in">
          <div className="mb-8 flex justify-center">
            <div className="relative">
              <img
                src="https://miaoda-conversation-file.s3cdn.medo.dev/user-7stho71ex69s/conv-7sthuc0vx0jk/20251125/file-7stmi9jl0fls.jpg"
                alt="Vishnu Bhardwaj"
                className="w-40 h-40 xl:w-56 xl:h-56 rounded-full object-cover border-4 border-primary glow-effect"
              />
            </div>
          </div>
          <h1 className="text-4xl xl:text-6xl font-bold mb-4 gradient-text">
            Vishnu Bhardwaj
          </h1>
          <p className="text-lg xl:text-2xl text-muted-foreground mb-4">
            Student at SRM University Sonipat
          </p>
          <div className="flex justify-center mb-4">
            <Button
              asChild
              className="bg-primary text-primary-foreground hover:bg-primary/90 transition-all duration-300"
            >
              <a
                href="https://www.linkedin.com/in/vishnu-bhardwaj"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2"
              >
                <Linkedin className="w-5 h-5" />
                Connect on LinkedIn
              </a>
            </Button>
          </div>
          <div className="w-24 h-1 bg-primary mx-auto rounded-full animate-glow-pulse" />
        </section>

        <section className="mb-16 xl:mb-20">
          <div className="flex items-center gap-3 mb-8">
            <GraduationCap className="w-8 h-8 text-primary" />
            <h2 className="text-3xl xl:text-4xl font-bold text-primary">Academics</h2>
          </div>
          <div className="mb-8 rounded-lg overflow-hidden glow-effect">
            <img
              src="https://miaoda-site-img.s3cdn.medo.dev/images/0bbe20c5-90e3-4e87-8940-5fe4c30a4062.jpg"
              alt="University campus"
              className="w-full h-64 xl:h-96 object-cover"
            />
          </div>
          <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
            {academics.map((item, index) => (
              <Card
                key={index}
                className="glow-effect bg-card border-border hover:border-primary transition-all duration-300"
              >
                <CardHeader>
                  <CardTitle className="text-primary text-xl">{item.level}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <p className="text-foreground font-semibold">{item.school}</p>
                  {item.location && (
                    <p className="text-muted-foreground text-sm">{item.location}</p>
                  )}
                  {item.board && (
                    <p className="text-muted-foreground text-sm">{item.board}</p>
                  )}
                  {item.score && (
                    <p className="text-secondary font-bold text-lg">{item.score}</p>
                  )}
                  {item.status && (
                    <p className="text-accent font-semibold">{item.status}</p>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        <section className="mb-16 xl:mb-20">
          <div className="flex items-center gap-3 mb-8">
            <Trophy className="w-8 h-8 text-secondary" />
            <h2 className="text-3xl xl:text-4xl font-bold text-secondary">Achievements</h2>
          </div>
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
            {achievements.map((item, index) => (
              <Card
                key={index}
                className="glow-effect bg-card border-border hover:border-secondary transition-all duration-300 overflow-hidden"
              >
                <div className="h-48 overflow-hidden">
                  <img
                    src={item.image}
                    alt={item.title}
                    className="w-full h-full object-cover hover:scale-110 transition-transform duration-300"
                  />
                </div>
                <CardHeader>
                  <CardTitle className="text-secondary text-xl">{item.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-foreground">{item.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        <section className="mb-16 xl:mb-20">
          <div className="flex items-center gap-3 mb-8">
            <Code className="w-8 h-8 text-primary" />
            <h2 className="text-3xl xl:text-4xl font-bold text-primary">Skills</h2>
          </div>
          <div className="mb-8 rounded-lg overflow-hidden glow-effect">
            <img
              src="https://miaoda-site-img.s3cdn.medo.dev/images/17fc4e43-0bf1-428f-8ccf-5396529af69e.jpg"
              alt="Programming workspace"
              className="w-full h-64 xl:h-80 object-cover"
            />
          </div>
          <Card className="glow-effect bg-card border-border hover:border-primary transition-all duration-300">
            <CardHeader>
              <CardTitle className="text-primary text-xl">Programming Languages</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex flex-wrap gap-3">
                {skills.languages.map((lang, index) => (
                  <span
                    key={index}
                    className="px-4 py-2 bg-muted text-primary border border-primary rounded-lg font-semibold hover:bg-primary hover:text-primary-foreground transition-all duration-300 cursor-default"
                  >
                    {lang}
                  </span>
                ))}
              </div>
              <div className="pt-4 border-t border-border">
                <p className="text-muted-foreground font-semibold">Interests:</p>
                <p className="text-foreground text-lg mt-2">{skills.interests}</p>
              </div>
            </CardContent>
          </Card>
        </section>

        <section className="mb-16">
          <div className="flex items-center gap-3 mb-8">
            <Briefcase className="w-8 h-8 text-secondary" />
            <h2 className="text-3xl xl:text-4xl font-bold text-secondary">My Work</h2>
          </div>
          <Card className="glow-effect bg-card border-border hover:border-secondary transition-all duration-300 overflow-hidden">
            <div className="h-64 overflow-hidden">
              <img
                src="https://miaoda-site-img.s3cdn.medo.dev/images/6ebce273-efe4-4360-8cca-48ac5e2c5c41.jpg"
                alt="Web application dashboard"
                className="w-full h-full object-cover hover:scale-110 transition-transform duration-300"
              />
            </div>
            <CardHeader>
              <CardTitle className="text-secondary text-xl">Self-Built Application</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-foreground mb-4">
                Check out my self-built application showcasing my development skills and creativity.
              </p>
              <Button
                asChild
                className="bg-secondary text-secondary-foreground hover:bg-secondary/90 transition-all duration-300"
              >
                <a
                  href="https://class-hub-54a7c1cb.base44.app"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2"
                >
                  Visit Application
                  <ExternalLink className="w-4 h-4" />
                </a>
              </Button>
            </CardContent>
          </Card>
        </section>

        <footer className="text-center py-8 border-t border-border">
          <p className="text-muted-foreground">
            2025 Vishnu Bhardwaj - Portfolio
          </p>
        </footer>
      </div>
    </div>
  );
}
