# Portfolio Landing Page Requirements Document

## 1. Website Name
Vishnu Bhardwaj - Portfolio

## 2. Website Description
A personal portfolio landing page showcasing academic background, achievements, skills, and projects of Vishnu Bhardwaj, a student at SRM University Sonipat.

## 3. Website Sections & Content

### 3.1 Info Section
- Name: Vishnu Bhardwaj
- Current Status: Student at SRM University Sonipat
\n### 3.2 Academics Section
- Class 10: Mount Carmel ICSE School, Patna, Bihar - 10%
- Class 12: St. Paul's High School, CBSE - 93%
- Current: SRM University Sonipat

### 3.3 Achievement Section
- NDA Merit Out\n- National Level Tabla Player: Performed at renowned platforms including Sonpur Mela (Asia's largest Sonpur Fair)\n\n### 3.4 Skills Section
- Programming Languages: Java (DSA), C, JavaScript, HTML, CSS\n- Interests: Vibe coding and learning enthusiast
\n### 3.5 My Work Section
- Self-built App: https://class-hub-54a7c1cb.base44.app
\n## 4. Design Style
- Color Scheme: Black background as primary base color, with contrasting accent colors (bright cyan or neon green) for text and highlights to create modern tech aesthetic
- Visual Effects: Hover effects applied to all sections with smooth scale or glow transitions; animated bubble effect in background with floating motion; smooth animated transitions between section interactions
- Layout: Single-page scrolling layout with distinct card-style sections, each section separated with subtle spacing for clear visual hierarchy
- Typography: Modern sans-serif fonts with varying weights to distinguish headings from body text